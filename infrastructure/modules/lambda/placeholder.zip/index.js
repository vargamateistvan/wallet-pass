exports.handler = async (event) => ({ statusCode: 200, body: JSON.stringify({ message: "Deploy your backend code" }) });
